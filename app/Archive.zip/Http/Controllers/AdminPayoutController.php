<?php

namespace App\Http\Controllers;

use App\Models\FailedPayout;
use App\Services\VendorPayoutService;
use App\Models\PaymentHistory;

class AdminPayoutController extends Controller
{
    public function index()
    {
        return FailedPayout::with('order')->latest()->get();
    }

    public function paymentHistory()
    {
        return PaymentHistory::with(['order', 'shop'])
            ->orderByDesc('created_at')
            ->get();
    }


    public function retry($id)
    {
        $failed = FailedPayout::with('order.shop.admin')->findOrFail($id);
        $service = new VendorPayoutService();
        $service->payVendor($failed->order);

        $failed->update(['resolved' => true]);

        PaymentHistory::updateOrCreate(
            ['order_id' => $failed->order->id],
            [
                'shop_id' => $failed->order->shop->admin->id,
                'amount' => $failed->amount,
                'reference' => $failed->order->payment_reference,
                'channel' => 'paystack',
                'status' => 'success',
            ]
        );

        return response()->json(['success' => true]);
    }
}
